document.write("External file");
console.log("External file");